const dialog = document.getElementById('preview-dialog');
const previewTitle = document.getElementById('preview-title');
const previewContent = document.getElementById('preview-content');
const closeButton = document.getElementById('close-preview');

document.querySelectorAll('[data-preview]').forEach((button) => {
  button.addEventListener('click', () => {
    const file = button.dataset.preview;
    previewTitle.textContent = button.dataset.title || 'Document preview';
    previewContent.replaceChildren();
    const frame = document.createElement('iframe');
    frame.title = `${previewTitle.textContent} - first four pages`;
    // The website must link only to a PDF already truncated to four pages.
    // #page=1 opens at the beginning; the actual page limit is enforced by the preview PDF itself.
    frame.src = `${file}#page=1&view=FitH&toolbar=0&navpanes=0&scrollbar=1`;
    frame.loading = 'lazy';
    frame.addEventListener('error', () => {
      previewContent.innerHTML = '<p class="missing-file">This preview is not available yet. Add the corresponding four-page preview PDF to the assets folder and redeploy the site.</p>';
    });
    previewContent.appendChild(frame);
    dialog.showModal();
  });
});

closeButton.addEventListener('click', () => dialog.close());
dialog.addEventListener('click', (event) => {
  if (event.target === dialog) dialog.close();
});
dialog.addEventListener('close', () => previewContent.replaceChildren());
