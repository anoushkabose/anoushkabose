# Anoushka Bose Portfolio (GitHub Pages)

A responsive static portfolio built with HTML, CSS, and JavaScript. It uses Times New Roman throughout and includes Selected Work, Writing, Profile, education, skills, and LinkedIn links.

## Add your files

Place the following files in `assets/` before publishing:

- `profile-photo.jpg` — your actual profile photograph
- `west-bengal-air-quality-preview.pdf`
- `water-scarcity-rajasthan-preview.pdf`
- `feminization-agriculture-preview.pdf`
- `telecommunication-bill-preview.pdf`
- `c40-good-food-cities-preview.pdf` (optional)

**Important PDF note:** Create separate preview PDFs that contain only pages 1–4 of each source document. Do not put the full source PDFs in the public `assets/` folder. GitHub Pages is static hosting; an iframe toolbar setting is not security and cannot prevent access to later pages if you publish the full PDF. To enforce a four-page limit, publish only the four-page preview copies.

If a PDF has fewer than four pages, use the full shorter PDF. If the C-40 document is not available, you can remove that publication card or leave it as unavailable until you have the file.

## Publish using GitHub Pages

1. Create a GitHub repository, for example `anoushka-bose-portfolio`.
2. Upload `index.html`, `styles.css`, `script.js`, `README.md`, and the `assets/` folder.
3. In the repository, open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then save.
6. Wait for GitHub Pages to publish the site. The URL will be shown in Settings → Pages.

No build step or package installation is required.

## Accuracy note

Review all experience wording and figures before publishing. This site reflects the information supplied in the brief; it does not independently verify employment claims or source documents.
